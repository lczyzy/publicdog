﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelCachorro.Model
{
    //classe de composição que vai receber uma lista de produtos e serviços para exibir
    class Pacote
    {


    }
}
