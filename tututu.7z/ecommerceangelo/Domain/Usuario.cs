﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Domain
{

    [Table("Usuarios")]
    public class Usuario
    {
        [Key]
        public int IdUsuario { get; set; }

        [Display(Name = "Email:")]
        [Required(ErrorMessage = "Campo obrigatório!")]
        [EmailAddress(ErrorMessage = "Email Inválido!")]
        public String Email { get; set; }

        [Display(Name = "Senha:")]
        [Required(ErrorMessage = "Campo obrigatório!")]
        [MinLength(3, ErrorMessage = "Mínimo de 3 caracteres!")]
        public String Senha { get; set; }

        [Display(Name = "Confirmar Senha:")]
        [Required(ErrorMessage = "Campo obrigatório!")]
        [MinLength(3, ErrorMessage = "Mínimo de 3 caracteres!")]
        [Compare("Senha", ErrorMessage = "Os campos não são iguais!")]
        [NotMapped]
        public String ConfirmarSenha { get; set; }

        [Display(Name = "Endereço:")]
        [Required(ErrorMessage = "Campo obrigatório!")]
        [MinLength(5, ErrorMessage = "Mínimo de 5 caracteres!")]
        public Endereco Endereco { get; set; }

        public DateTime CriadoEm { get; set; }

        public Usuario() { CriadoEm = DateTime.Now; }
    }
}
