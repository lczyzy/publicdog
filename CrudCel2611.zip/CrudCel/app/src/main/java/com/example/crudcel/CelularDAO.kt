package com.example.crudcel

import androidx.lifecycle.LiveData
import androidx.room.*



@Dao
interface CelularDAO {

    @Insert
    fun insert(celular: Celular)

    @Update
    fun update(celular: Celular)

    @Delete
    fun delete(celular: Celular)


    @Query("SELECT * FROM celular_tb ORDER BY modelo_cl ASC")
    fun getAll(): LiveData<List<Celular>>

    @Query("SELECT * FROM celular_tb WHERE id = :id_")
    fun getByID(id_: Int): LiveData<Celular>

    @Query("DELETE FROM celular_tb")
    fun deleteAll()


}