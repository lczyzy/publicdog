package com.example.crudcel


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData

import com.example.crudcelular.Repository.CelularRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext

class CelularViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CelularRepository

    val celulares: LiveData<List<Celular>>


    private val parentJob = Job()
    private val corountineContext: CoroutineContext
        get() = parentJob + Dispatchers.Main
    private val scope = CoroutineScope(corountineContext)

    init {
        val celularDAO = HelperDatabase.getDatabase(application).celularDao()
        repository = CelularRepository(celularDAO)

        celulares = repository.allCelulares
    }

    fun insert(celular: Celular) = scope.launch(Dispatchers.IO){
        repository.insert(celular)
    }

    fun update(celular: Celular) = scope.launch(Dispatchers.IO){
        repository.update(celular)
    }

    fun delete(celular: Celular) = scope.launch(Dispatchers.IO){
        repository.delete(celular)
    }

}