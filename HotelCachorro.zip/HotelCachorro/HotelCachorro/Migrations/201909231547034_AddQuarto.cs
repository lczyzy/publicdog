namespace HotelCachorro.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddQuarto : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Quartos",
                c => new
                    {
                        IdQuarto = c.Int(nullable: false, identity: true),
                        NomeQuarto = c.String(),
                        Status = c.String(),
                    })
                .PrimaryKey(t => t.IdQuarto);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Quartos");
        }
    }
}
