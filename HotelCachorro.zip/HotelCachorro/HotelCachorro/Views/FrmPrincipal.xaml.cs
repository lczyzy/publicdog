﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HotelCachorro.Views
{
    /// <summary>
    /// Interaction logic for FrmPrincipal.xaml
    /// </summary>
    public partial class FrmPrincipal : Window
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            
        }

        private void CadastrarCliente(object sender, RoutedEventArgs e)
        {
            frmCadastrarCliente f = new frmCadastrarCliente();
            f.ShowDialog();
        }

        private void acaoSair(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void AdicionarPet(object sender, RoutedEventArgs e)
        {
            frmAddPet faPet = new frmAddPet();
            faPet.ShowDialog();
        }

        private void BuscarCliente(object sender, RoutedEventArgs e)
        {
            FrmBuscarCliente bc = new FrmBuscarCliente();
            bc.ShowDialog();
        }

        private void ListarClientes(object sender, RoutedEventArgs e)
        {
            frmListarClientes lc = new frmListarClientes();
            lc.ShowDialog();
        }

        private void ExcluirCliente(object sender, RoutedEventArgs e)
        {
            frmExcluirCliente ec = new frmExcluirCliente();
            ec.ShowDialog();
        }

        private void EditarClientes(object sender, RoutedEventArgs e)
        {
            frmEditarCliente fec = new frmEditarCliente();
            fec.ShowDialog();
        }

    

        private void FazerReserva(object sender, RoutedEventArgs e)
        {
            frmFazerReserva fr = new frmFazerReserva();
            fr.ShowDialog();
        }
    }
}
