﻿using HotelCachorro.DAL;
using HotelCachorro.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HotelCachorro.Views
{
    /// <summary>
    /// Interaction logic for frmFazerReserva.xaml
    /// </summary>
    public partial class frmFazerReserva : Window
    {
        public frmFazerReserva()
        {
            InitializeComponent();
        }

        private void CarregarDados(object sender, RoutedEventArgs e)
        {
            cboQuartos.ItemsSource = QuartoDAO.ListarQuartosLivres();
            cboQuartos.DisplayMemberPath = "NomeQuarto";
            cboQuartos.SelectedValuePath = "IdQuarto";
        }

        private void BuscarPet(object sender, RoutedEventArgs e)
        {
           // int buscarPet = Convert.ToInt32(cboPets.SelectedValue);

            Cliente c = new Cliente
            {
                Cpf = TxtCpf.Text
            };

            c = ClienteDAO.BuscarClientePorCPF(c);
            if (c != null)
            {
                cboPets.ItemsSource = PetDAO.ListarPetPorCliente(c.IdCliente);
                cboQuartos.DisplayMemberPath = "Nome";
                cboQuartos.SelectedValuePath = "IdPet";
                //cboPets.Text = c.Genero.Nome;
            }
            else
            {
                MessageBox.Show("Esse cliente não possui pets!", "Hotel Cachorro");
            }

        }
    }
}
