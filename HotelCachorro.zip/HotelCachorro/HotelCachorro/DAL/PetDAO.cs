﻿using HotelCachorro.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelCachorro.DAL
{
    class PetDAO
    {
        private static Context ctx = SingletonContext.GetInstance();


        public static Pet ListarPetPorCliente(Pet p)
        {
            return ctx.Pets.ToList().Where(x => x.cliente.IdCliente == p.IdPet).ToList();
        }

        public static Pet BuscarPetPorNome(Pet p)
        {
            return ctx.Pets.FirstOrDefault
                (x => x.Nome.Equals(p.Nome));
        }

        public static bool CadastrarPet(Pet p)
        {

            if(BuscarPetPorNome(p) == null)
            {
                ctx.Pets.Add(p);
                ctx.SaveChanges();
                return true;
            }

            return false;
            
        }
    }
}
