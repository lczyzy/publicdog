﻿using HotelCachorro.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelCachorro.DAL
{
    class QuartoDAO
    {

        private static Context ctx = SingletonContext.GetInstance();


        public static List<Quarto> ListarQuartos()
        {
            return ctx.Quartos.ToList();
        }

        public static List<Quarto> ListarQuartosLivres()
        {
            return ctx.Quartos.ToList().Where(x => x.Status != "Ocupado").ToList();
        }

        public static Quarto BuscarQuartoPorId(int quarto)
        {
            return ctx.Quartos.FirstOrDefault(x => x.IdQuarto == quarto);
        }

    }
}
