﻿namespace HotelCachorro.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MigNew : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Funcoes",
                c => new
                    {
                        FuncaoId = c.Int(nullable: false, identity: true),
                        Nome = c.String(),
                    })
                .PrimaryKey(t => t.FuncaoId);
            
            CreateTable(
                "dbo.ItensVendas",
                c => new
                    {
                        IdVenda = c.Int(nullable: false, identity: true),
                        Nome = c.String(),
                        Preco = c.Double(nullable: false),
                        Quantidade = c.Int(nullable: false),
                        Produto_IdProduto = c.Int(),
                        Reserva_IdReserva = c.Int(),
                        Servico_IdServico = c.Int(),
                    })
                .PrimaryKey(t => t.IdVenda)
                .ForeignKey("dbo.Produtos", t => t.Produto_IdProduto)
                .ForeignKey("dbo.Reservas", t => t.Reserva_IdReserva)
                .ForeignKey("dbo.Servicos", t => t.Servico_IdServico)
                .Index(t => t.Produto_IdProduto)
                .Index(t => t.Reserva_IdReserva)
                .Index(t => t.Servico_IdServico);
            
            AddColumn("dbo.Funcionario", "Funcao_FuncaoId", c => c.Int());
            AddColumn("dbo.Pet", "Raca", c => c.String());
            AddColumn("dbo.Pet", "Castragem", c => c.String());
            AddColumn("dbo.Pet", "Pelagem", c => c.String());
            AddColumn("dbo.Pet", "Idade", c => c.Int(nullable: false));
            AddColumn("dbo.Pet", "Porte", c => c.String());
            AddColumn("dbo.Pet", "Peso", c => c.Double(nullable: false));
            AddColumn("dbo.Pet", "Genero_GeneroId", c => c.Int());
            AlterColumn("dbo.Reservas", "DataEntrada", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Reservas", "DataSaida", c => c.DateTime(nullable: false));
            CreateIndex("dbo.Funcionario", "Funcao_FuncaoId");
            CreateIndex("dbo.Pet", "Genero_GeneroId");
            AddForeignKey("dbo.Funcionario", "Funcao_FuncaoId", "dbo.Funcoes", "FuncaoId");
            AddForeignKey("dbo.Pet", "Genero_GeneroId", "dbo.Generos", "GeneroId");
            DropColumn("dbo.Funcionario", "Funcao");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Funcionario", "Funcao", c => c.String());
            DropForeignKey("dbo.ItensVendas", "Servico_IdServico", "dbo.Servicos");
            DropForeignKey("dbo.Pet", "Genero_GeneroId", "dbo.Generos");
            DropForeignKey("dbo.ItensVendas", "Reserva_IdReserva", "dbo.Reservas");
            DropForeignKey("dbo.ItensVendas", "Produto_IdProduto", "dbo.Produtos");
            DropForeignKey("dbo.Funcionario", "Funcao_FuncaoId", "dbo.Funcoes");
            DropIndex("dbo.Pet", new[] { "Genero_GeneroId" });
            DropIndex("dbo.ItensVendas", new[] { "Servico_IdServico" });
            DropIndex("dbo.ItensVendas", new[] { "Reserva_IdReserva" });
            DropIndex("dbo.ItensVendas", new[] { "Produto_IdProduto" });
            DropIndex("dbo.Funcionario", new[] { "Funcao_FuncaoId" });
            AlterColumn("dbo.Reservas", "DataSaida", c => c.DateTime());
            AlterColumn("dbo.Reservas", "DataEntrada", c => c.DateTime());
            DropColumn("dbo.Pet", "Genero_GeneroId");
            DropColumn("dbo.Pet", "Peso");
            DropColumn("dbo.Pet", "Porte");
            DropColumn("dbo.Pet", "Idade");
            DropColumn("dbo.Pet", "Pelagem");
            DropColumn("dbo.Pet", "Castragem");
            DropColumn("dbo.Pet", "Raca");
            DropColumn("dbo.Funcionario", "Funcao_FuncaoId");
            DropTable("dbo.ItensVendas");
            DropTable("dbo.Funcoes");
        }
    }
}
