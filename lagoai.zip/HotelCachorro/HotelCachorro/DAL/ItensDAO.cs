﻿using HotelCachorro.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelCachorro.DAL
{
    class ItensDAO
    {

        private static Context ctx = SingletonContext.GetInstance();

        public static List<ItemVenda> ProdutosPorCliente(Reserva r)
        {
            return ctx.ItensVenda.Where(x => x.Reserva.IdReserva == r.IdReserva).ToList();
        }

        public static List<ItemVenda> ProdutosPorClienteXX(int valor)
        {
            return ctx.ItensVenda.Include("Produto").Include("Servico").Where(x => x.Reserva.IdReserva == valor).ToList();
        }


        public static ItemVenda RemoverVendaPorId(int reserva)
        {
            // return ctx.ItensVenda.Remove(x => x.Reserva.IdReserva == reserva);
            //return ctx.ItensVenda.Remove(reserva);
        }

        /*
        public static bool ExcluirItens(Reserva r)
        {
            ItemVenda iv;
            iv = ProdutosPorCliente(r);
            if (r != null)
            {
                ctx.ItensVenda.Remove(r.ItensVendidos);
                ctx.SaveChanges();
                return true;

            }
            return false;
        }
        */
    }
}
